At positions you specify, players can ring at the "reception" and the specified job will receive a notification that someone has rung the bell.

# Preview: https://streamable.com/1ven6x
# Discord: https://discord.gg/xX8cdtbgeg
