Config = {
    Control = 51, -- E
    ShowHelpNotification = "~INPUT_CONTEXT~ Klingel betätigen", -- ring the bell notification
    WaitAfterBell = 10000, -- 10 seconds
    Position = {
        {pos = vector3(438.74417114258, -987.93365478516, 30.724325180054), job = "police"},
        {pos = vector3(440.29974365234, -984.40850830078, 30.724325180054), job = "police"},
    }
}
